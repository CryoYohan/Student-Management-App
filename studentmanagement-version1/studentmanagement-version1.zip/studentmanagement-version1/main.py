from window import Window

def main()->None:
    app = Window()
   
if __name__ == ("__main__"):
    main()